﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace library
{
    public partial class add_Book : Form
    {
        public add_Book()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source = DESKTOP-AFMPLMB ; Initial Catalog = Librarynew1 ;Integrated Security = true ; User ID='' ; Password = ''");
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string q = @"insert into book(_year,title,Id_book,price,num_copies,ID_reader,ID_author,ID_category) values(" +yearinp.Text+ ",'" + titleinp.Text + "'," + bookidinp.Text + "," +priceinp.Text+ "," + numcopiesinp.Text + ",0000,0000,0000);";
            SqlCommand cmd = new SqlCommand(q, con);
            MenuForm o = new MenuForm();
            cmd.ExecuteNonQuery();
            o.Show();
            this.Hide();
            con.Close();
        }
    }
}
