﻿
namespace library
{
    partial class admin_sign_in
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.admin_IdInput = new System.Windows.Forms.TextBox();
            this.adminPassInp = new System.Windows.Forms.TextBox();
            this.adminPassIn = new System.Windows.Forms.Label();
            this.FirstNameInput = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.LastNameInput = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(48, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "admin_Id";
            // 
            // admin_IdInput
            // 
            this.admin_IdInput.AllowDrop = true;
            this.admin_IdInput.Location = new System.Drawing.Point(139, 133);
            this.admin_IdInput.Name = "admin_IdInput";
            this.admin_IdInput.Size = new System.Drawing.Size(178, 22);
            this.admin_IdInput.TabIndex = 1;
            // 
            // adminPassInp
            // 
            this.adminPassInp.Location = new System.Drawing.Point(139, 179);
            this.adminPassInp.Name = "adminPassInp";
            this.adminPassInp.Size = new System.Drawing.Size(178, 22);
            this.adminPassInp.TabIndex = 5;
            // 
            // adminPassIn
            // 
            this.adminPassIn.AutoSize = true;
            this.adminPassIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminPassIn.Location = new System.Drawing.Point(16, 180);
            this.adminPassIn.Name = "adminPassIn";
            this.adminPassIn.Size = new System.Drawing.Size(117, 18);
            this.adminPassIn.TabIndex = 4;
            this.adminPassIn.Text = "admin password";
            // 
            // FirstNameInput
            // 
            this.FirstNameInput.Location = new System.Drawing.Point(139, 232);
            this.FirstNameInput.Name = "FirstNameInput";
            this.FirstNameInput.Size = new System.Drawing.Size(178, 22);
            this.FirstNameInput.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(48, 232);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 18);
            this.label4.TabIndex = 6;
            this.label4.Text = "first name";
            // 
            // LastNameInput
            // 
            this.LastNameInput.Location = new System.Drawing.Point(139, 281);
            this.LastNameInput.Name = "LastNameInput";
            this.LastNameInput.Size = new System.Drawing.Size(178, 22);
            this.LastNameInput.TabIndex = 9;
            this.LastNameInput.TextChanged += new System.EventHandler(this.LastNameInput_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(48, 285);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 18);
            this.label5.TabIndex = 8;
            this.label5.Text = "last name";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(409, 216);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 39);
            this.button1.TabIndex = 10;
            this.button1.Text = "save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Save);
            // 
            // admin_sign_in
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.LastNameInput);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.FirstNameInput);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.adminPassInp);
            this.Controls.Add(this.adminPassIn);
            this.Controls.Add(this.admin_IdInput);
            this.Controls.Add(this.label1);
            this.Name = "admin_sign_in";
            this.Text = "admin_sign_in";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox admin_IdInput;
        private System.Windows.Forms.TextBox adminPassInp;
        private System.Windows.Forms.Label adminPassIn;
        private System.Windows.Forms.TextBox FirstNameInput;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox LastNameInput;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
    }
}