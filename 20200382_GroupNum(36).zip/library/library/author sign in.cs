﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace library
{
    public partial class author_sign_in : Form
    {
        public author_sign_in()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source = DESKTOP-AFMPLMB ; Initial Catalog = Librarynew1 ;Integrated Security = true ; User ID='' ; Password = ''");
        private void click_save(object sender, EventArgs e)
        {
            con.Open();
            string q = @"insert into author(city,country,id_author,first_name,last_name) values('"+cityinput.Text+"','"+countryinput.Text+"',"+authoridinput.Text+",'"+FirstNameInput.Text+"','"+LastNameInput.Text+"');";
            SqlCommand cmd = new SqlCommand(q, con);
            Form1 o = new Form1();
            o.Show();
            this.Hide();
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
