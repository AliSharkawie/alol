﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace library
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source = DESKTOP-AFMPLMB ; Initial Catalog = Librarynew1 ;Integrated Security = true ; User ID='' ; Password = ''");
        private void logIn_Click(object sender, EventArgs e)
        {
            try
            {
                string username, ppassword;
                username = username_txt.Text;
                ppassword = userpassword_txt.Text;
                string querry = "SELECT * FROM adminstrator WHERE first_name = '" + username_txt.Text+"'AND adminPassword = '"+userpassword_txt.Text+"'";
                SqlDataAdapter sda = new SqlDataAdapter(querry, con); 
                 DataTable dtable = new DataTable();
                sda.Fill(dtable);   
                if (dtable.Rows.Count > 0)
                {
                    username = username_txt.Text;
                    ppassword = userpassword_txt.Text;
                    MenuForm newform = new MenuForm();
                    newform.Show();
                    this.Hide();
                }
                else
                {

                    MessageBox.Show("Invalid login!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    username_txt.Clear();
                    userpassword_txt.Clear();

                    username_txt.Focus();
                }
            }
            catch
            {    
                MessageBox.Show("Error");
            }
            finally
            {
                con.Close();
            }
        }

        private void click_sign(object sender, EventArgs e)
        {
            sign_up sign = new sign_up();
            sign.Show();
            this.Hide();
        }
    }
}
