﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace library
{
    public partial class sign_up : Form
    {
        public sign_up()
        {
            InitializeComponent();
        }

        private void click_reader(object sender, EventArgs e)
        {
            reader_sign_in inp= new reader_sign_in();
            inp.Show();
            this.Hide();
        }

        private void click_author(object sender, EventArgs e)
        {
            author_sign_in inp = new author_sign_in();
            inp.Show();
            this.Hide();
        }

        private void click_admin(object sender, EventArgs e)
        {
            admin_sign_in inp = new admin_sign_in();
            inp.Show();
            this.Hide();
        }
    }
}
