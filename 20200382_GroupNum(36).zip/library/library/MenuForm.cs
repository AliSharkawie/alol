﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace library
{
    public partial class MenuForm : Form
    {
        public MenuForm()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source = DESKTOP-AFMPLMB ; Initial Catalog = Librarynew1 ;Integrated Security = true ; User ID='' ; Password = ''");
        private void addBook(object sender, EventArgs e)
        {
            add_Book bb = new add_Book();
            bb.Show();
            this.Hide();
        }

        private void showBooks(object sender, EventArgs e)
        {
            show_books bb = new show_books();
            bb.Show();
            this.Hide();
        }
    }
}
