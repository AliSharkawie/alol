﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace library
{

    public partial class admin_sign_in : Form
    {
        public admin_sign_in()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source = DESKTOP-AFMPLMB ; Initial Catalog = Librarynew1 ;Integrated Security = true ; User ID='' ; Password = ''");
        private void Save(object sender, EventArgs e)
        {
            con.Open();
            string q = @"insert into adminstrator(ID_admin, adminPassword, first_name, last_name) values("+admin_IdInput.Text+","+adminPassInp.Text+", '"+FirstNameInput.Text+"','"+LastNameInput.Text+"');";
            SqlCommand cmd = new SqlCommand(q, con);
            Form1 o = new Form1();
            o.Show();
            this.Hide();
            cmd.ExecuteNonQuery();
            con.Close();
           // insert into adminstrator(ID_admin, adminPassword, first_name, last_name) values(45, 8651, 'alaa', 'ashraf');
        }

        private void LastNameInput_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
